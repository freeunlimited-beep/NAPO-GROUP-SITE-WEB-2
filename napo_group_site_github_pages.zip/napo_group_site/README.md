# Site web NAPO GROUP — publication gratuite avec GitHub Pages

Ce dossier contient un site vitrine responsive en français, avec le logo fourni, une présentation institutionnelle, les activités, les projets, la formation et un formulaire qui prépare un message WhatsApp.

## Fichiers
- `index.html` : contenu du site
- `styles.css` : design rouge, blanc et noir, adapté au téléphone
- `script.js` : menu mobile, année automatique et formulaire WhatsApp
- `assets/napo-group-logo.png` : logo fourni

## Publication gratuite depuis Android
1. Ouvrir https://github.com et se connecter.
2. Créer un dépôt public nommé `napo-group-site` (ou choisir un dépôt existant).
3. Ajouter les fichiers et le dossier `assets` en conservant exactement leur structure.
4. Dans le dépôt, ouvrir **Settings** → **Pages**.
5. Dans **Build and deployment**, choisir **Deploy from a branch**.
6. Choisir la branche `main` et le dossier `/ (root)`, puis **Save**.
7. Attendre la publication. L'adresse sera du type `https://VOTRE-PSEUDO.github.io/napo-group-site/`.

Pour une adresse plus courte `https://VOTRE-PSEUDO.github.io/`, le dépôt doit porter exactement le nom `VOTRE-PSEUDO.github.io`.

## À vérifier avant publication
- Vérifier le numéro WhatsApp `+228 90 84 75 76` et l'adresse `napogroup1@gmail.com`.
- Ajouter les liens des réseaux sociaux officiels si souhaité.
- Ajouter des photos réelles et les coordonnées publiques définitives.
- Les chiffres clés et informations historiques sont présentés comme des données communiquées par NAPO GROUP, pas comme un audit indépendant.
- Les projets sont identifiés comme projets en développement ou concepts lorsque leur mise en service n'est pas établie.
- Le formulaire ouvre WhatsApp : il n'enregistre ni n'envoie les données vers une base de données.

## Limites de cette version
C'est un site vitrine statique. Il n'inclut pas encore de connexion membre, tableau de bord, base de données, paiement en ligne, gestion de commandes ou espace administrateur. Ces fonctions nécessitent des services supplémentaires et une configuration sécurisée.
