const menuButton = document.querySelector('.menu-toggle');
const nav = document.querySelector('.main-nav');
menuButton.addEventListener('click', () => {
  const opened = nav.classList.toggle('open');
  menuButton.setAttribute('aria-expanded', String(opened));
  menuButton.textContent = opened ? '✕' : '☰';
});
document.querySelectorAll('.main-nav a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  menuButton.setAttribute('aria-expanded', 'false');
  menuButton.textContent = '☰';
}));
document.getElementById('year').textContent = new Date().getFullYear();
document.getElementById('contact-form').addEventListener('submit', event => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const message = [
    'Bonjour NAPO GROUP,',
    'Nom : ' + form.get('name'),
    'E-mail : ' + form.get('email'),
    'Objet : ' + form.get('subject'),
    'Message : ' + form.get('message')
  ].join('\n');
  window.open('https://wa.me/22890847576?text=' + encodeURIComponent(message), '_blank', 'noopener');
});
